<?php

return array (
  'singular' => 'Funcip',
  'plural' => 'Funcips',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'ano' => 'Ano',
    'idmeses' => 'Meses',
    'modulo' => 'Módulo',
    'valor_estimado_pagamento' => 'Valor Estimado Pagamento',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
