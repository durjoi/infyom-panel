<?php

return array (
  'singular' => 'Cidade',
  'plural' => 'Cidades',
  'fields' =>
  array (
    'id' => 'ID',
    'descricao' => 'Descrição',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
