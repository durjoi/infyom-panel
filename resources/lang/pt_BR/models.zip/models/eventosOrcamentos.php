<?php

return array (
  'singular' => 'Eventos Orcamento',
  'plural' => 'Eventos Orcamentos',
  'fields' =>
  array (
    'id' => 'ID',
    'quantidade' => 'Quantidade',
    'incluidodoem' => 'Incluido em',
    'id_eventos' => 'Eventos',
    'id_contrato_itens' => 'Contrato',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
