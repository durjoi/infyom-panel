<?php

return array (
  'singular' => 'Controle de Históricos',
  'plural' => 'Controle de Históricos',
  'fields' =>
  array (
    'id' => 'ID',
    'descricao' => 'Descrição',
    'id_solicitacao_reclamacao' => 'Solicitação da Reclamação',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
