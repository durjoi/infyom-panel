<?php

return array (
  'singular' => 'IP Conta IP 10',
  'plural' => 'IP Conta IP 10',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'cod_cliente' => 'Código Cliente',
    'nome' => 'Nome',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
