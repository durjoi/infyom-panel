<?php

return array (
  'singular' => 'Obras Solicitante',
  'plural' => 'Obras Solicitantes',
  'fields' =>
  array (
    'id' => 'ID',
    'idobras' => 'Obra',
    'solicitante_nome' => 'Solicitante Nome',
    'solicitante_telefone' => 'Solicitante Telefone',
    'solicitante_email' => 'Solicitante Email',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
