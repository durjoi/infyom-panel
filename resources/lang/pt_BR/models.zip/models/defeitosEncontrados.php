<?php

return array (
  'singular' => 'Defeitos Encontrados',
  'plural' => 'Defeitos Encontrados',
  'fields' =>
  array (
    'id' => 'ID',
    'defeito_encontrato_descricao' => 'Descrição',
    'incluidodoem' => 'Incluido em',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
