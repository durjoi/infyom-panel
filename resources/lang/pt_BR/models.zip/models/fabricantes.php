<?php

return array (
  'singular' => 'Fabricante',
  'plural' => 'Fabricantes',
  'fields' =>
  array (
    'id' => 'ID',
    'fabricante_descricao' => 'Descrição',
    'incluidodoem' => 'Incluido em',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
