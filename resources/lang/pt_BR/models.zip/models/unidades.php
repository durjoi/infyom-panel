<?php

return array (
  'singular' => 'Unidade',
  'plural' => 'Unidade',
  'fields' =>
  array (
    'id' => 'ID',
    'abreviado' => 'Abreviado',
    'unidade_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
