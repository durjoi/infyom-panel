<?php

return array (
  'singular' => 'Operação',
  'plural' => 'Operações',
  'fields' =>
  array (
    'id' => 'ID',
    'operacao' => 'Operação',
    'utilizacao' => 'Utilizacao',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
