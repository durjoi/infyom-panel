<?php

return array (
  'singular' => 'Obras Estoque',
  'plural' => 'obras_estoques',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'obras_estoque_descricao' => 'Descrição',
    'tipo' => 'Tipo',
    'status' => 'Status',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
