<?php

return array (
  'singular' => 'Sequencial',
  'plural' => 'Sequenciais',
  'fields' =>
  array (
    'id' => 'ID',
    'protocolo' => 'Protocolo',
    'entrada' => 'Entrada',
    'saida' => 'Saida',
    'poste_numero' => 'Número do Poste',
    'obras' => 'Obras',
    'eventos' => 'Eventos',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
