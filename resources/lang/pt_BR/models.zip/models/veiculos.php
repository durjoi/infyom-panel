<?php

return array (
  'singular' => 'Veiculo',
  'plural' => 'Veiculos',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'placa' => 'Placa',
    'descricao' => 'Descrição',
    'ano' => 'Ano',
    'propriedade' => 'Propriedade',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
