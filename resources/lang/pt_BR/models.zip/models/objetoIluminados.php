<?php

return array (
  'singular' => 'Objeto Iluminado',
  'plural' => 'Objetos Iluminados',
  'fields' =>
  array (
    'id' => 'ID',
    'objeto_iluminado_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
