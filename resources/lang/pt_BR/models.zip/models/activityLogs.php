<?php

return array (
  'singular' => 'Log de Atividade',
  'plural' => 'Log de atividades',
  'fields' =>
  array (
    'id' => 'ID',
    'log_name' => 'Nome do log',
    'description' => 'Descrição',
    'subject_id' => 'Assunto',
    'subject_type' => 'Tipo do assunto',
    'causer_id' => 'usuário',
    'causer_type' => 'Tipo do usuário',
    'properties' => 'Propriedades',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
  ),
);


