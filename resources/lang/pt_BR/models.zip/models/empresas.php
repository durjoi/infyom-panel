<?php

return array (
  'singular' => 'Empresas',
  'plural' => 'Empresas',
  'fields' =>
  array (
    'id' => 'ID',
    'empresa_nome' => 'Nome',
    'empresa_descricao' => 'Descrição',
    'incluidodoem' => 'Incluido em',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
