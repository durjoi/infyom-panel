<?php

return array (
  'singular' => 'Requisição',
  'plural' => 'Requisições',
  'fields' =>
  array (
    'id' => 'ID',
    'data_operacao' => 'Data Operação',
    'operacao' => 'Operação',
    'solicitante' => 'Solicitante',
    'autorizado_por' => 'Autorizado Por',
    'obras' => 'Obras',
    'bairro' => 'Bairro',
    'turma' => 'Turma',
    'observacao' => 'Observação',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
