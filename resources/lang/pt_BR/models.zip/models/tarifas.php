<?php

return array (
  'singular' => 'Tarifa',
  'plural' => 'Tarifas',
  'fields' =>
  array (
    'id' => 'ID',
    'tipo' => 'Tipo',
    'idmeses' => 'Meses',
    'ano_referencia' => 'Ano Referência',
    'valor' => 'Valor',
    'aliquota' => 'Aliquota',
    'resolucao_annel' => 'Resolucao Annel',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
