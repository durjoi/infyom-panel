<?php

return array (
  'singular' => 'Tipo Solicitação',
  'plural' => 'Tipo Solicitaçoes',
  'fields' =>
  array (
    'id' => 'ID',
    'tiposolicitacao_descricao' => 'Descrição',
    'tiposolicitacao_aplicacao' => 'Aplicação',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
