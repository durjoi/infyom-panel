<?php

return array (
  'singular' => 'Fatura Manutenção OS',
  'plural' => 'Fatura Manutenção OS',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idfaturamanutencao' => 'Fatura Manutenção',
    'idsolicitacaoreclamacao' => 'Solicitação Reclamação',
    'valor_os' => 'Valor OS',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
