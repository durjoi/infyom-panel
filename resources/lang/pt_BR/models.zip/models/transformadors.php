<?php

return array (
  'singular' => 'Transformador',
  'plural' => 'Transformadores',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'codigo' => 'Código',
    'numerocia' => 'Numerocia',
    'idlogradouro' => 'Logradouro',
    'idbairro' => 'Bairro',
    'poste_numero' => 'Número do Poste',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
