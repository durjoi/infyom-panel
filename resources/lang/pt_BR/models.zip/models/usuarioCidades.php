<?php

return array (
  'singular' => 'Usuario Cidade',
  'plural' => 'Usuario Cidades',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
