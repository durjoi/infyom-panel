<?php

return array (
  'singular' => 'Estoque Entradas Produto',
  'plural' => 'Estoque Entradas Produtos',
  'fields' =>
  array (
    'id' => 'ID',
    'quantidade' => 'Quantidade',
    'dev_mat_novo_def' => 'Dev Mat Novo Def',
    'dev_mat_n_apl' => 'Dev Mat N Apl',
    'dev_mat_apl' => 'Dev Mat Apl',
    'valor_unitario' => 'Valor Unitário',
    'valor_total' => 'Valor Total',
    'incluidodoem' => 'Incluido em',
    'id_entrada' => 'Entrada',
    'id_producto' => 'Produto',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
