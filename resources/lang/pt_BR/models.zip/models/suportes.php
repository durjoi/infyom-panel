<?php

return array (
  'singular' => 'Suporte',
  'plural' => 'Suportes',
  'fields' =>
  array (
    'id' => 'ID',
    'suporte_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
