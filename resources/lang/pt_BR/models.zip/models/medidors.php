<?php

return array (
  'singular' => 'Medidor',
  'plural' => 'Medidores',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'numero' => 'Numero',
    'idlogradouro' => 'Logradouro',
    'idbairro' => 'Bairro',
    'poste_numero' => 'Número do Poste',
    'contrato' => 'Contrato',
    'capacidade_medicao' => 'Capacidade Medição',
    'capacidade_disjuntor' => 'Capacidade Disjuntor',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
