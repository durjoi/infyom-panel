<?php

return array (
  'singular' => 'Ajustes no Contrato dos Itens',
  'plural' => 'Ajustes no Contrato dos Itens',
  'fields' =>
  array (
    'id' => 'ID',
    'data_inicio' => 'Data do Início',
    'ajuste' => 'Ajuste',
    'incluidodoem' => 'Incluido em',
    'id_contrato' => 'Contrato',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
