<?php

return array (
  'singular' => 'Resposta Mensagem Diaria',
  'plural' => 'Respostas Mensagem Diaria',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idusuarioreceber' => 'Usuário Receber',
    'enviadoem' => 'Enviado em',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
