<?php

return array (
  'singular' => 'Luminária',
  'plural' => 'Luminárias',
  'fields' =>
  array (
    'id' => 'ID',
    'luminaria_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
