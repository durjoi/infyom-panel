<?php

return array (
  'singular' => 'Obras_Orcamento',
  'plural' => 'Obras_Orcamentos',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idobras' => 'Obra',
    'idcontratoitens' => 'Contrato Itens',
    'quantidade_mo' => 'Quantidade Mo',
    'origem_mo' => 'Origem Mo',
    'quantidade_mt' => 'Quantidade Mt',
    'origem_mt' => 'Origem Mt',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
