<?php

return array (
  'singular' => 'Relê',
  'plural' => 'Relês',
  'fields' =>
  array (
    'id' => 'ID',
    'rele_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
