<?php

return array (
  'singular' => 'Tipo Solicitante',
  'plural' => 'Tipo Solicitantes',
  'fields' =>
  array (
    'id' => 'ID',
    'tiposolicitante_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
