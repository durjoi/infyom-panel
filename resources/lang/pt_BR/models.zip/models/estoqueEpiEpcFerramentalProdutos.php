<?php

return array (
  'singular' => 'Estoque EPI EPC Ferramental Produtos',
  'plural' => 'Estoque EPI EPC Ferramental Produtos',
  'fields' =>
  array (
    'id' => 'ID',
    'quantidade' => 'Quantidade',
    'valor_unitario' => 'Valor Unitário',
    'incluidodoem' => 'Incluido em',
    'id_estoque_epi_epc_ferramental' => 'Estoque Epi Epc Ferramental',
    'id_produtos' => 'Produtos',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
