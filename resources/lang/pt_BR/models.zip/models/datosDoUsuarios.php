<?php

return array (
  'singular' => 'Dados do Usuário',
  'plural' => 'Dados do Usuário',
  'fields' =>
  array (
    'id' => 'ID',
    'nome' => 'Nome',
    'email' => 'Email',
    'senha' => 'Senha',
    'tipo' => 'Tipo',
    'telefone_ddd' => 'DDD do Telefone',
    'telefone_numero' => 'Número do Telefone ',
    'empresa' => 'Empresa',
    'cargo_setor' => 'Setor do Cargo',
    'direcionar' => 'Direcionar',
    'mensagem_instantanea' => 'Mensagem Instantânea',
    'receber_sms' => 'Receber SMS',
    'w_acesso_whatsapp' => 'Acesso Whatsapp',
    'w_menu_consultas' => 'Menu  Consultas',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
