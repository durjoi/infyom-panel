<?php

return array (
  'singular' => 'IP Conta IP Secretarias',
  'plural' => 'IP Conta IP Secretarias',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'secretaria_sigla' => 'Secretaria Sigla',
    'secretaria_nome' => 'Secretaria Nome',
    'secretaria_tipo' => 'Secretaria Tipo',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
