<?php

return array (
  'singular' => 'Estoque EPI EPC Ferramental',
  'plural' => 'Estoque EPI EPC Ferramental',
  'fields' =>
  array (
    'id' => 'ID',
    'autorizado_por' => 'Autorizado Por',
    'actualicao' => 'Actualição',
    'observacao' => 'Observação',
    'incluidodoem' => 'Incluido em',
    'id_operacao' => 'Operação',
    'id_empregados' => 'Empregados',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
