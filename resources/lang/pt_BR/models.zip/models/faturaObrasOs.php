<?php

return array (
  'singular' => 'Fatura Obras OS',
  'plural' => 'Fatura Obras OS',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idfaturaobras' => 'Fatura Obras',
    'idobras' => 'Obra',
    'valor_os' => 'Valor OS',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
