<?php

return array (
  'singular' => 'Resposta',
  'plural' => 'Respostas',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'modulo' => 'Módulo',
    'submodulo' => 'Submodulo',
    'descricao' => 'Descrição',
    'tipo' => 'Tipo',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
