<?php

return array (
  'singular' => 'IP Conta IP 11',
  'plural' => 'IP Conta IP 11',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'tipo_reg' => 'Tipo Reg',
    'cnpj' => 'CNPJ',
    'cod_cliente' => 'Código Cliente',
    'cod_contrato' => 'Código Contrato',
    'cod_multiservico' => 'Código Multiserviço',
    'compl_nome' => 'Complemento Nome',
    'endereco_rua_av' => 'Endereço Rua Av',
    'endereco_compl' => 'Endereço Compl',
    'endereco_bairro' => 'Endereço Bairro',
    'endereco_municipio_uf_cep' => 'Endereço Municipio Uf CEP',
    'contaipano' => 'Contaip Ano',
    'contaipmes' => 'Contaip Mês',
    'contaipdatainclusao' => 'Data Inclusão',
    'contaipusuariologin' => 'Usuário Login',
    'segmento' => 'Segmento',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
