<?php

return array (
  'singular' => 'Lâmpada',
  'plural' => 'Lâmpadas',
  'fields' =>
  array (
    'id' => 'ID',
    'lampada_descricao' => 'Descrição',
    'lampada_potencia' => 'Potencia',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'lampada_abreveada' => 'Abreveada',
    'perda_rator' => 'Perda Rator',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
