<?php

return array (
  'singular' => 'Resposta Usuários',
  'plural' => 'Respostas Usuários',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idrespostas' => 'Respostas',
    'idusuarioreceber' => 'Usuário Receber',
    'receber_mensagem_instantanea' => 'Receber Mensagem Instantânea',
    'receber_mensagem_diaria' => 'Receber Mensagem Diaria',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
