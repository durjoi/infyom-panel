<?php

return array (
  'singular' => 'Pedido Produto',
  'plural' => 'Pedidos Produto',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idpedido' => 'Pedido',
    'idprodutos' => 'Produtos',
    'qtd_solicitada' => 'Qtd Solicitada',
    'qtd_recebida' => 'Qtd Recebida',
    'observacoes' => 'Observações',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
