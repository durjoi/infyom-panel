<?php

return array (
  'singular' => 'Solicitação Reclamação Solicitantes',
  'plural' => 'Solicitações Reclamação Solicitantes',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idsolicitacaoreclamacao' => 'Solicitação Reclamação',
    'nome' => 'Nome',
    'telefone' => 'Telefone',
    'email' => 'Email',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
