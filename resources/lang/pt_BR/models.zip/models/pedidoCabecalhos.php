<?php

return array (
  'singular' => 'Pedido Cabecalho',
  'plural' => 'Pedido Cabecalhos',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'centro_custo' => 'Centro Custo',
    'almoxarifado' => 'Almoxarifado',
    'telefone_fixo' => 'Telefone Fixo',
    'telefone_celular' => 'Telefone Celular',
    'cnpj' => 'CNPJ',
    'inscricao_estadual' => 'Inscrição Estadual',
    'gerente_geral' => 'Gerente Geral',
    'encarregado_eletrica' => 'Encarregado Eletrica',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
