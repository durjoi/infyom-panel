<?php

return array (
  'singular' => 'Turma',
  'plural' => 'Turmas',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'cabo_turma' => 'Cabo Turma',
    'outros' => 'Outros',
    'situacao' => 'Situacão',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
