<?php

return array (
  'singular' => 'Fatura Eventos OS',
  'plural' => 'Fatura Eventos OS',
  'fields' =>
  array (
    'id' => 'ID',
    'valor_os' => 'Valor OS',
    'incluidodoem' => 'Incluido em',
    'id_factura_eventos' => 'Fatura Eventos',
    'id_eventos' => 'Eventos',
    'id_cidade' => 'Cidade',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
