<?php

return array (
  'singular' => 'Rede',
  'plural' => 'Redes',
  'fields' =>
  array (
    'id' => 'ID',
    'rede_descricao' => 'Descrição',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
