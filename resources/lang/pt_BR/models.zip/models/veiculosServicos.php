<?php

return array (
  'singular' => 'Veiculos Servicos',
  'plural' => 'veiculos Servicos',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idveiculos' => 'Veiculos',
    'data_servico' => 'Data Serviço',
    'descricao_servico' => 'Descrição Serviço',
    'valor_total' => 'Valor Total',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
