<?php

return array (
  'singular' => 'Mensagem',
  'plural' => 'Mensagens',
  'fields' =>
  array (
    'id' => 'ID',
    'idusuario_de' => 'Usuário De',
    'idusuario_para' => 'Usuário Para',
    'enviadaem' => 'Enviada em',
    'titulo' => 'Título',
    'corpo' => 'Corpo',
    'situacao' => 'Situacão',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
