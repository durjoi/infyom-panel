<?php

return array (
  'singular' => 'Solicitação Material Itens',
  'plural' => 'Solicitações Material Itens',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idcontratoitens' => 'Contrato Itens',
    'mo_quantidade' => 'Mo Quantidade',
    'mo_origem' => 'Mo Origem',
    'mt_quantidade' => 'Mt Quantidade',
    'mt_origem' => 'Mt Origem',
    'idusuario' => 'Usuário',
    'item_com_vandalismo' => 'Item Com Vandalismo',
    'sucata_nao_retornada' => 'Sucata Nao Retornada',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
