<?php

return array (
  'singular' => 'Item',
  'plural' => 'Itens',
  'fields' =>
  array (
    'id' => 'ID',
    'produto' => 'Produto',
    'marca' => 'Marca',
    'unidade' => 'Unidade',
    'quantidade' => 'Quantidade',
    'preco_total' => 'Preco Total',
    'ordem_de_servico_id' => 'Fk Ordem De Servico',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
