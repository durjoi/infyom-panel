<?php

return array (
  'singular' => 'Empregados',
  'plural' => 'Empregados',
  'fields' =>
  array (
    'id' => 'ID',
    'nome' => 'Nome',
    'funcao' => 'Função',
    'admissao' => 'Admissão',
    'desligamento' => 'Desligamento',
    'situacao' => 'Situação',
    'incluidodoem' => 'Incluido em',
    'id_usuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
