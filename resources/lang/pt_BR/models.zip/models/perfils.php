<?php

return array (
  'singular' => 'Perfil',
  'plural' => 'Perfís',
  'fields' =>
  array (
    'id' => 'ID',
    'idusuario' => 'Usuário',
    'idperfilcadastro' => 'Perfil Cadastro',
    'incluidoem' => 'Incluido em',
    'idusuario_incluido' => 'Usuário Incluido',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
