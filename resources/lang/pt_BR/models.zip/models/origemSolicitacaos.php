<?php

return array (
  'singular' => 'Origem Solicitação',
  'plural' => 'Origem Solicitações',
  'fields' =>
  array (
    'id' => 'ID',
    'origemsolicitacao_codigo' => 'Código',
    'origemsolicitacao_descricao' => 'Descrição',
    'origemsolicitacao_descritivo' => 'Descritivo',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
