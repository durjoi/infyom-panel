<?php

return array (
  'singular' => 'Solicitacão Material',
  'plural' => 'Solicitacões Material',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idsolicitacaoreclamacao' => 'Solicitação Reclamação',
    'idcontratoitens' => 'Contrato Itens',
    'mo_quantidade' => 'Mo Quantidade',
    'mo_origem' => 'Mo Origem',
    'mt_quantidade' => 'Mt Quantidade',
    'mt_origem' => 'Mt Origem',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'item_com_vandalismo' => 'Item Com Vandalismo',
    'sucata_nao_retornada' => 'Sucata Nao Retornada',
    'garantia' => 'Garantia',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
