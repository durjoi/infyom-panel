<?php

return array (
  'singular' => 'Reator',
  'plural' => 'Reatores',
  'fields' =>
  array (
    'id' => 'ID',
    'reator_descricao' => 'Descrição',
    'reator_perda' => 'Perda',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
