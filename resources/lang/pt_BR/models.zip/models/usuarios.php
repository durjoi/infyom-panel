<?php

return array (
  'singular' => 'Usuario',
  'plural' => 'Usuarios',
  'fields' =>
  array (
    'id' => 'ID',
    'nome' => 'Nome',
    'email' => 'Email',
    'senha' => 'Senha',
    'tipo' => 'Tipo',
    'telefone_ddd' => 'DDD do Telefone',
    'telefone_numero' => 'Número do Telefone ',
    'empresa' => 'Empresa',
    'cargo_setor' => 'Setor do Cargo',
    'direcionar' => 'Direcionar',
    'mensagem_instantanea' => 'Mensagem Instantânea',
    'receber_mensagem' => 'Receber Mensagem',
    'receber_sms' => 'Receber SMS',
    'incluidoem' => 'Incluido em',
    'w_acesso_whatsapp' => 'W Acesso Whatsapp',
    'w_menu_consultas' => 'W Menu Consultas',
    'w_menu_veiculos' => 'W Menu Veiculos',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
