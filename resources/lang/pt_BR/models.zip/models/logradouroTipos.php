<?php

return array (
  'singular' => 'Logradouro Tipo',
  'plural' => 'Logradouro Tipos',
  'fields' =>
  array (
    'id' => 'ID',
    'logradouro_tipo_descricao' => 'Descrição',
    'logradouro_tipo_abreviado' => 'Abreviado',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
