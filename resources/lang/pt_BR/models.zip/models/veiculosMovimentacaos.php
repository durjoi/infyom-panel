<?php

return array (
  'singular' => 'Veiculos Movimentação',
  'plural' => 'Veiculos_movimentações',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idveiculos' => 'Veiculos',
    'saida' => 'Saida',
    'retorno' => 'Retorno',
    'incluidoem' => 'Incluido em',
    'idusuario' => 'Usuário',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
