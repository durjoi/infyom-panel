<?php

return array (
  'singular' => 'Fatura Obras',
  'plural' => 'Fatura Obras',
  'fields' =>
  array (
    'id' => 'ID',
    'idcidade' => 'Cidade',
    'idempresa' => 'Empresa',
    'numero' => 'Número',
    'idmeses' => 'Meses',
    'ano' => 'Ano',
    'situacao' => 'Situação',
    'aberta_em' => 'Aberta em',
    'aberta_idusuario' => 'Aberta Usuário',
    'encaminhada_em' => 'Encaminhada em',
    'encaminhada_idusuario' => 'Encaminhada Usuário',
    'pago_em' => 'Pago em',
    'pago_idusuario' => 'Pago Usuário',
    'data_inicio' => 'Data do Início',
    'data_termino' => 'Data do Término',
    'titulo_relatorio' => 'Título Relatório',
    'created_at' => 'Criado em',
    'updated_at' => 'Editado em',
    'deleted_at' => 'Deletado em',
  ),
);
